import './App.css';
import Content from './components/Content';
import Follow from './components/Follow';
import NavigationSideBar from './components/NavigationSideBar';
import followers from './follow.json';


function App() {
  return (
    <div className="app">
      
        <NavigationSideBar name='Explore'/>
        <Content/>
        <Follow data={followers}/>
    </div>
  );
}

export default App;

import React from 'react'
import './nav.css'

function SearchBar() {
  return (
    <div className='search-bar'>
        <div className='search'>
            <a href='#'><img src={require('../assets/search.png')} style={{height:'20px', width:'20px', marginLeft: '5px', marginTop: '2.5px', marginRight: '5px'}}></img></a>
            <input type='text' placeholder='Search Tuiter' className='search-input'></input>
        </div>
        <div className='search-settings'>
            <img src={require('../assets/settings.png')} style={{height:'30px', width:'30px'}}/>
        </div>
    </div>
  )
}

export default SearchBar
import React from 'react';
import './nav.css';
import QuickLinks from './QuickLinks';
import SearchBar from './SearchBar';
import MainContent from './MainContent';
import summary from './summary.json'

function Content() {
  return (
    <div className='content'>
        <SearchBar/>
        <QuickLinks/>
        <MainContent data={summary}/>
    </div>
  )
}

export default Content
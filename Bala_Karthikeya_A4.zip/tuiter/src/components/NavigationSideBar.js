import React from "react";
import "./nav.css";
import { useState } from "react";

function NavigationSideBar(props) {
  const [name, setName] = useState(props.name);
  const items = [
    "Tuiter",
    "Home",
    "Explore",
    "Notifications",
    "Messeges",
    "Bookmarks",
    "Lists",
    "Profile",
    "More",
  ];
  return (
    <div className="wd-navbar-side">
        {items.map((item, index) => (
          <a
            key={index}
            href={`#${item}`}
            className={`wd-navbar-item ${item === name ? "active" : ""}`}
            onClick={() => setName(item)}
          >
            {item}
          </a>
        ))}
      </div>
  );
}

export default NavigationSideBar;

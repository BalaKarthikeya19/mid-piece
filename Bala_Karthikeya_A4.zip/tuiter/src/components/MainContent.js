import React from "react";
import "./nav.css";

function MainContent(props) {
  const data = props.data;
  return (
    <div className="main-content">
      <div className="main-content-item">
        <img src={require('../assets/naruto.jpg')} style={{ width:'100%', borderRadius:'5px'}}/>
        <h1 style={{color:'#fe0000', zIndex:'1', position:'absolute', bottom:'10px', left:'10px'}}>Naruto X Kurama</h1>
      </div>
      {data.map((item) => (
        <div className="main-content-item">
          <div className="main-content-item-left" key={item._id}>
            <p style={{color:'grey'}}>
              <span>{item.userName}</span>
              <span> .{item.time}</span>
            </p>
            <p><b>{item.topic}</b></p>
            <p>{item.title}</p>
          </div>
          <div className="main-content-item-right">
            <img src={require(`../assets/${item.image}`)}></img>
          </div>
        </div>
      ))}
    </div>
  );
}

export default MainContent;

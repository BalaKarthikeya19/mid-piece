import React from "react";

function Follow(props) {
  const data = props.data;
  return (
    <div className="follow">
      <h3 style={{padding: '5px'}}><light>Who to follow</light></h3>
      <hr></hr>
      {data.map((item) => (
        <div key={item.id} className="follow-item">
          <img src={require(`../assets/${item.avatar}`)} alt={item.username} className="follow-img" />
          {item.username}
          <br></br>
          {item.handle}
          <a href='#' style={{padding : "5px", background:"rgb(0, 136, 255)", borderRadius:"15px", textDecoration:"none", color:"white"}}> Follow </a>
        </div>
      ))}
    </div>
  );
}

export default Follow;

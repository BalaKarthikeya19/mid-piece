import React from "react";
import "./nav.css";
import { useState } from "react";

function QuickLinks() {
  const links = ["For you", "Trending", "Sports", "Entertainment", "News"];
  const [active, setActive] = useState(links[0]);
  return (
    <div className="quick-links">
      {links.map((link) => (
          <a
            href={`#${link}`}
            style={{ 
                textDecoration: "none", 
                padding:'5px',
                borderRadius:'5px'
            }}
            className={`${link === active ? 'current':''}`}
            onClick={()=>setActive(link)}
          >
            {link}
          </a>
      ))}
    </div>
  );
}

export default QuickLinks;
